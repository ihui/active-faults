Tibetean Active Faults
=============

>Tibet Plateau Faults   
>version:2  
>coordinate system:GCS_WGS_1984  
>the last edited time:20/8/2013  
>by Shao Yanxiu

=============
###shp文件要素  

name:断裂名称  
type:断裂类型  
strike:断裂走向  
dip:断裂倾向  
dipan:断裂倾角  
time:断裂活动时代  

=============  
###added faults：
贺兰山东麓断裂  
崇岗-芦花台断裂  
三关口断裂  
银川-平罗隐伏断裂  
黄河断裂  
正谊关断裂  
雅布赖断裂


=============
###Contributors：

Lei Qiyun, Yu Jingxing

